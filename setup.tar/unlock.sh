#!/bin/sh
activator send libactivator.system.homebutton
activator send libactivator.lockscreen.dismiss
sleep 0.5
echo "$(date) - WallDashBoard Unlocked!" >> /var/root/unlock.log
echo "WallDashBoard Unlocked!"
