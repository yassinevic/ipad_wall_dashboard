#!/bin/sh
sleep 0.3
read input
case "$input" in
  "unlock")
    /var/root/unlock.sh
    ;;
  "battery")
    /var/root/battery.sh
    ;;
  *)
    echo "unknown command"
    ;;
esac
