#!/bin/bash
LINE=$(grep '\[Battery\]' /private/var/mobile/Library/Logs/CurrentPowerlog.powerlog | sed -n '$p') LEVEL=${LINE#*level=}; LEVEL=${LEVEL%%;*}; LEVEL=${LEVEL%%%*} 
STATE=${LINE#*charging_state=}; STATE=${STATE%%;*} TEMP=${LINE#*battery_temp=}; TEMP=${TEMP%%;*}; TEMP=${TEMP%%C*}; TEMP=${TEMP%% } [ "$STATE" = "Inactive" ] && STATE=0 || STATE=1
echo "$LEVEL|$STATE|$TEMP"
